#include"opencv2/opencv.hpp"
#include <librealsense2/rs.hpp> // Include RealSense Cross Platform API
#include "/home/trexozz/catkin_ws/src/librealsense/wrappers/opencv/cv-helpers.hpp"
#include <iostream>

#include <librealsense2/rs.hpp> // Include RealSense Cross Platform API
#include <librealsense2/rsutil.h>
#include "/home/trexozz/catkin_ws/src/librealsense/examples/example.hpp"
#include "/home/trexozz/catkin_ws/src/librealsense/third-party/imgui/imgui.h"
#include "/home/trexozz/catkin_ws/src/librealsense/third-party/imgui/imgui_impl_glfw.h"
#include "opencv2/tracking.hpp"

#include "opencv2/imgcodecs.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/videoio.hpp"
#include <opencv2/highgui.hpp>
#include <opencv2/video.hpp>


#include "/home/trexozz/catkin_ws/src/librealsense/wrappers/opencv/cv-helpers.hpp"

#include <sstream>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cstring>
#include <chrono>
#include <eigen3/Eigen/Dense>

#include <librealsense2/rs.hpp> // Include RealSense Cross Platform API
#include <librealsense2/rsutil.h>

// This example will require several standard data-structures and algorithms:
#define _USE_MATH_DEFINES
#include <math.h>
#include <queue>
#include <unordered_set>
#include <map>
#include <thread>
#include <atomic>
#include <mutex>
#include "ros/ros.h"
#include "track3d/ball_trajectory.h"

using namespace std;
using namespace cv;
using namespace std::chrono;
using pixel = std::pair<int, int>;

double max_average = 0.0,min_average = 100.0;
int global_write_flag = 0;
pixel p1,pOrigin1,pLeft1,pUpper1;
Vec3f ref_frame_info[3];
int width = 480, height = 270;
const char* image_window = "Source Image";
const char* thresholded_image="thresholded";
const char* is_detected = "detected??";
int align_acc_flag=0;
vector<Vec3f> circles;
high_resolution_clock::time_point t_frame1;
high_resolution_clock::time_point t_frame2;

vector<float> dist_3d(const rs2::depth_frame& frame, pixel u);
void write_to_file(std::string, std::vector<Vec6f>, std::vector<double>);
Point MatchingMethod( Mat, Mat);
Point circle_detect(Mat);
Vec3f* ref_init(Mat img, Vec3f ref_info[]);
float get_depth_scale(rs2::device dev);
rs2_stream find_stream_to_align(const std::vector<rs2::stream_profile>& streams);
void blob_detection(Mat);
void CallBackFunc(int, int, int, int, void*);

Vec2f pixel_pos_1;
Vec2f pixel_pos_2;
bool found = false;

int main(int argc, char *argv[])try
{
    //ROS specifics:
    //----------------
    //Initializing ROS node with a name of demo_topic_publisher
    ros::init(argc, argv,"ball_detection");
    //Created a nodehandle object
    ros::NodeHandle node_obj;
    //Create a publisher object
    ros::Publisher ball_trajectory_publisher = node_obj.advertise<track3d::ball_trajectory>
            ("/ball_trajectory_topic",10);
    //create msg holder
    track3d::ball_trajectory ball_trajectory_msg;
    int publish_flag = 1; // Note:: 1:if u want to publish 0:if u don't

    //refrence frame variables:
    //--------------------------
    int ref_assign_flag = 0; // Note:: 0: if u want to detect reference frame 1: if u don't
    Vec3f* ref_info, left_dot, origin, upper_dot;
    Vec3f vector_a, vector_b, unitVec_a, unitVec_b, unitVec_c;
    vector<float> origin_from_cam, left_from_cam, upper_from_cam;
    Vec3f dist_ball_from_ref1, ball_diff_ref, velocity_vector, pos_old;
    double vec_magA, vec_magB;

    //ball position and velocity per frame variables:
    //------------------------------------------------
    int frame_count = 0, vel_flag = 0, point_num = 0, publish_count = 0;
    vector<Vec6f> ball_trajectory_data, ball_trajectory_data_cam;
    vector<double> time_stamp;
    double t_1 = 0, t_2 = 0, delta_t = 0;
    int track_flag = 1; // Note:: 1: if u wan't to track ball 0: if u don't

    //tracking variables:
    //-----------------------
    Rect2d bbox;
    bool ok = false;
    Ptr<Tracker> tracker;
    tracker = TrackerKCF::create();
    bool flag_start = 0;

    //template matching variables:
    //-----------------------------
    //Mat templ = imread( "/home/trexozz/ball_templates/template_0_51_169_10_104_200.jpg" );
    Mat template_img = imread( "/home/trexozz/ball_templates/template_0_51_169_10_104_200.jpg" );
    Mat fgMaskMOG;
    Ptr<BackgroundSubtractor> pMOG2;
    pMOG2 = createBackgroundSubtractorMOG2(); //MOG approach
    //pMOG->apply(frame, fgMaskMOG);
    //imshow("FG Mask MOG", fgMaskMOG);
    int took_cropped_part = 1; // Note:: 0:if u want to take a new template, 1: if u don't
    int threshold_values_initialize = 0; // Note:: 1:if u want to recalculate(shaking), 0: if u don't
    int window_w=0, window_h=0;
    double minVal=0, maxVal=0;
    int b_lower=0,g_lower=0,r_lower=0,b_upper=0,g_upper=0,r_upper=0;
    int b_lim = 0, g_lim = 0, r_lim = 0;
    b_lower = 0; // Note:: these values should be updated with the new calculated thresholds
    g_lower = 50;
    r_lower = 131;
    b_upper = 120;
    g_upper = 107;
    r_upper = 207;
    Point minLoc, maxLoc;
    //inRange(templ, cv::Scalar(0, 0, 0), cv::Scalar(255, 255, 255), templ);
    resize(template_img,template_img,Size(3,3));
    namedWindow("choose_pixel", 1);
    namedWindow("thresholded_img", 1);
    setMouseCallback("choose_pixel", CallBackFunc, NULL);

    //camera variables:
    //-------------------
    namedWindow( image_window, WINDOW_AUTOSIZE );
    rs2::decimation_filter dec;
    rs2::spatial_filter spat;

    //processing options
    dec.set_option(RS2_OPTION_FILTER_MAGNITUDE, 2);
    spat.set_option(RS2_OPTION_HOLES_FILL, 5); // 5 = fill all the zero pixels

    //stream profile and starting
    rs2::pipeline pipe;
    rs2::config cfg;
    cfg.enable_stream(RS2_STREAM_DEPTH,width,height,RS2_FORMAT_Z16);// Enable default depth
    cfg.enable_stream(RS2_STREAM_COLOR,424,240,RS2_FORMAT_RGBA8);
    auto profile = pipe.start(cfg);

    //aligning of the color and depth streams
    rs2_stream align_to = find_stream_to_align(profile.get_streams());
    rs2::align align(align_to);

    //geting sensor info
    auto sensor = profile.get_device().first<rs2::depth_sensor>();
    auto range = sensor.get_option_range(RS2_OPTION_VISUAL_PRESET);
    for (auto i = range.min; i < range.max; i += range.step)
        if (std::string(sensor.get_option_value_description(RS2_OPTION_VISUAL_PRESET, i)) == "High Density")
            sensor.set_option(RS2_OPTION_VISUAL_PRESET, i);

    // After initial post-processing, frames will flow into this queue:
    rs2::frame_queue postprocessed_frames;

    // Alive boolean will signal the worker threads to finish-up
    std::atomic_bool alive{ true };

    //frame capturing and alignment thread:
    //-----------------------------------------
    std::thread video_processing_thread([&]() {
        // In order to generate new composite frames, we have to wrap the processing
        // code in a lambda
        rs2::processing_block frame_processor(
                    [&](rs2::frameset data, // Input frameset (from the pipeline)
                    rs2::frame_source& source) // Frame pool that can allocate new frames
        {
            t_frame1= high_resolution_clock::now();
            data = data.apply_filter(align); //Here we align
            t_frame2 = high_resolution_clock::now();
        auto duration2 = duration_cast<milliseconds>(t_frame2-t_frame1).count();
        cout<<"Alignment time="<<duration2<<endl;

            source.frame_ready(data);
        });

        // Indicate that we want the results of frame_processor
        // to be pushed into postprocessed_frames queue
        frame_processor >> postprocessed_frames;

        while (alive)
        {
            // Fetch frames from the pipeline and send them for processing
            rs2::frameset fs;
            if (pipe.poll_for_frames(&fs)) frame_processor.invoke(fs);
        }
    });

    //Our main while loop:
    //------------------------
    while (waitKey(1) != int('q') && cvGetWindowHandle(image_window)) // Application still alive?
    {
        high_resolution_clock::time_point t1 = high_resolution_clock::now();
        static rs2::frameset current_frameset;

        if(postprocessed_frames.poll_for_frame(&current_frameset))
        {
            frame_count += 1;

            //reference frame detection:
            //----------------------------
            if (current_frameset && ref_assign_flag==0)
            {
                auto depth_1 = current_frameset.get_depth_frame(); //Aligned depth frame
                auto color_1 = current_frameset.get_color_frame();
                Mat img = frame_to_mat(color_1);
                ref_info=ref_init(img,ref_frame_info);
                cout<<"ref_info"<<ref_info[0]<<endl;
                left_dot=ref_info[1];
                upper_dot=ref_info[2];
                origin=ref_info[0];
                // Now we are ready to construct the new reference frame
                {

                    Point origin1 = Point(origin.val[0], origin.val[1]);
                    pOrigin1.first=origin1.x;
                    pOrigin1.second=origin1.y;

                    Point left1=Point(left_dot.val[0],left_dot.val[1]);
                    pLeft1.first=left1.x;
                    pLeft1.second=left1.y;

                    Point upper1=Point(upper_dot.val[0],upper_dot.val[1]);
                    pUpper1.first=upper1.x;
                    pUpper1.second=upper1.y;
                    //Now we have pixels of each and we need x y z distances of each
                    //Origin

                    origin_from_cam = dist_3d(depth_1,pOrigin1);
                    left_from_cam = dist_3d(depth_1,pLeft1);
                    upper_from_cam = dist_3d(depth_1,pUpper1);

                    //Now we have the distances
                    //cout<<"Origin from Cam: X="<<origin_from_cam[0]<<"  y="<<origin_from_cam[1]<<"  z="<<origin_from_cam[2]<<endl;
                    //cout<<"Left from Cam: X="<<left_from_cam[0]<<"  y="<<left_from_cam[1]<<"  z="<<left_from_cam[2]<<endl;
                    //cout<<"Upper from Cam: X="<<upper_from_cam[0]<<"  y="<<upper_from_cam[1]<<"  z="<<upper_from_cam[2]<<endl;
                    //cout<<"--------------------"<<endl;

                    //Constructing the reference frame
                    //---------------------------------------------
                    //Vector a
                    vector_a.val[0]=left_from_cam[0]-origin_from_cam[0];
                    vector_a.val[1]=left_from_cam[1]-origin_from_cam[1];
                    vector_a.val[2]=left_from_cam[2]-origin_from_cam[2];
                    //Vector b
                    vector_b.val[0]=upper_from_cam[0]-origin_from_cam[0];
                    vector_b.val[1]=upper_from_cam[1]-origin_from_cam[1];
                    vector_b.val[2]=upper_from_cam[2]-origin_from_cam[2];
                    //Calculating Magnitude
                    //A
                    vec_magA=sqrt(pow(vector_a.val[0],2)+pow(vector_a.val[1],2)+pow(vector_a.val[2],2));
                    //B
                    vec_magB=sqrt(pow(vector_b.val[0],2)+pow(vector_b.val[1],2)+pow(vector_b.val[2],2));

                    //Calculating unit vectors
                    //A
                    unitVec_a.val[0]=vector_a.val[0]/vec_magA;
                    unitVec_a.val[1]=vector_a.val[1]/vec_magA;
                    unitVec_a.val[2]=vector_a.val[2]/vec_magA;
                    //B
                    unitVec_b.val[0]=vector_b.val[0]/vec_magB;
                    unitVec_b.val[1]=vector_b.val[1]/vec_magB;
                    unitVec_b.val[2]=vector_b.val[2]/vec_magB;
                    //C
                    unitVec_c=unitVec_a;
                    unitVec_c=unitVec_b.cross(unitVec_c);

                    //cout<<"UnitVec_a-->"<<unitVec_a.val[0]<<" "<<unitVec_a.val[1]<<" "<<unitVec_a.val[2]<<endl;
                    //cout<<"UnitVec_b-->"<<unitVec_b.val[0]<<" "<<unitVec_b.val[1]<<" "<<unitVec_b.val[2]<<endl;
                    //cout<<"UnitVec_c-->"<<unitVec_c.val[0]<<" "<<unitVec_c.val[1]<<" "<<unitVec_c.val[2]<<endl;
                }
                ref_assign_flag=1;

            }

            //ball detection:
            //----------------
            else if (current_frameset)
            {

                auto depth = current_frameset.get_depth_frame(); //Aligned depth frame
                auto color = current_frameset.get_color_frame();

                Mat img = frame_to_mat(color);
                Mat processed, out;
                //cvtColor(img,processed,CV_BGR2HSV);

                GaussianBlur( img, processed, Size( 1, 1 ), 0, 0 );
                if(took_cropped_part==0)
                {
                    if(found == false)
                    {
                        //processed = remove_illumination(frame);
                        //frame.copyTo(processed);
                        //set the callback function for any mouse event
                        imshow("choose_pixel",processed);
                        // Wait until user press some key
                        if(waitKey(1) >= 0)break;
                        continue;
                    }
                    took_cropped_part = 1;
                    window_w = pixel_pos_2[0]-pixel_pos_1[0];
                    window_h = pixel_pos_2[1]-pixel_pos_1[1];
                    Rect2d box;
                    box.x = pixel_pos_1[0];
                    box.y = pixel_pos_1[1];
                    box.width = window_w;
                    box.height = window_h;
                    //namedWindow("tracker",1);
                    //rectangle( processed, box, Scalar::all(0), 2, 8, 0 );
                    //imshow("tracker",processed);
                    //while(waitKey(1) < 0){}
                    //Mat template_img;

                    // Split the image into different channels to find min and max values of each color
                    {
                        vector<Mat> rgbChannels(3);
                        processed(Rect(pixel_pos_1[0],pixel_pos_1[1],window_w,window_h)).copyTo(template_img);
                        split(template_img, rgbChannels);
                        minMaxLoc(rgbChannels[0], &minVal, &maxVal, &minLoc, &maxLoc);;
                        b_lower = minVal;
                        b_upper = maxVal;
                        minMaxLoc(rgbChannels[1], &minVal, &maxVal, &minLoc, &maxLoc);;
                        g_lower = minVal;
                        g_upper = maxVal;
                        minMaxLoc(rgbChannels[2], &minVal, &maxVal, &minLoc, &maxLoc);;
                        r_lower = minVal;
                        r_upper = maxVal;
                    }
                    imwrite("/home/abdelrhman/ball_templates/template_"+to_string(b_lower)+"_"+
                            to_string(g_lower)+"_"+to_string(r_lower)+"_"+to_string(b_upper)+"_"+
                            to_string(g_upper)+"_"+to_string(r_upper)+".jpg",template_img);
                    cout<<b_lower<<" "<<g_lower<<" "<<r_lower<<" "<<endl;
                    cout<<b_upper<<" "<<g_upper<<" "<<r_upper<<" "<<endl;
                    //inRange(template_img, cv::Scalar(b_lower,g_lower,r_lower),
                    //        cv::Scalar(b_upper,g_upper,r_upper), template_img);
                    //threshold(template_img,template_img,0,255,CV_THRESH_BINARY);
                    resize(template_img,template_img,Size(3,3));
                    continue;
                }

                //Detection Algorithm
                if (flag_start == 0 || ok == false) //if tracking is lost, then detect.
                {
                    GaussianBlur( img, processed, Size( 1, 1 ), 0, 0 );
                    pMOG2->apply(processed, fgMaskMOG);
                    imshow("FG Mask MOG", fgMaskMOG);
                    threshold(fgMaskMOG,fgMaskMOG,0,1,CV_THRESH_BINARY);
                    cvtColor(fgMaskMOG,fgMaskMOG,COLOR_GRAY2BGR);
                    multiply(fgMaskMOG,processed,processed);
                    Point center = MatchingMethod(processed,template_img);
                    if(threshold_values_initialize == 1)
                    {
                        // Split the image into different channels to find min and max values of each color
                        {
                            vector<Mat> rgbChannels(3);
                            split(processed(Rect(center.x,center.y,template_img.cols,template_img.rows)), rgbChannels);
                            minMaxLoc(rgbChannels[0], &minVal, &maxVal, &minLoc, &maxLoc);;
                            if(minVal<b_lower) b_lower = minVal;
                            if(maxVal>b_upper) b_upper = maxVal;
                            minMaxLoc(rgbChannels[1], &minVal, &maxVal, &minLoc, &maxLoc);;
                            if(minVal<g_lower) g_lower = minVal;
                            if(maxVal>g_upper) g_upper = maxVal;
                            minMaxLoc(rgbChannels[2], &minVal, &maxVal, &minLoc, &maxLoc);;
                            if(minVal<r_lower) r_lower = minVal;
                            if(maxVal>r_upper) r_upper = maxVal;
                        }
                        cout<<"----------------------------------------"<<endl;
                        cout<<b_lower<<" "<<g_lower<<" "<<r_lower<<endl;
                        cout<<b_upper<<" "<<g_upper<<" "<<r_upper<<endl;
                    }
                    inRange(processed, cv::Scalar(b_lower-b_lim,g_lower-g_lim,r_lower-r_lim),
                            cv::Scalar(b_upper+b_lim,g_upper+g_lim,r_upper+r_lim), out);
                    boxFilter(out, out,-1,Size(7,7));
                    threshold(out,out,0,255,CV_THRESH_BINARY);
                    imshow("thresholded_img",out);
                    auto value = mean(out);
                    if(value[0]==0)
                    {
                        continue;
                    }
                    if (center.x == -1 && center.y == -1)
                    {
                        continue;
                    }
                    p1.first=center.x;
                    p1.second=center.y;
//                    bbox.x = p1.first;
//                    bbox.y = p1.first;
//                    bbox.width = templ.rows;
//                    bbox.height = templ.cols;
                    rectangle( processed, center, Point(center.x + template_img.cols  ,  center.y + template_img.rows), Scalar::all(0), 2, 8, 0 );
//                    tracker->init(img, bbox);
//                    p1.first=center.x;
//                    p1.second=center.y;
//                    ok = true;
                    imshow(image_window,processed);
                }
//                else // else continue tracking.
//                {
//                    ok = tracker->update(img, bbox);
//                    rectangle(img, bbox, Scalar(0, 0, 0), 2, 1 );
//                    p1.first = bbox.x + (bbox.width/2);
//                    p1.second = bbox.y + (bbox.height/2);
//                    cout<<" in"<<endl;
//                }

                //getting found ball position and velocity data.
                //if (dist_3d(depth,p1)[2] > 0)
                if(track_flag == 1)
                {
                    //Calculating number of frames per second
                    t_2 = color.get_timestamp();
                    delta_t = fabs(t_2-t_1)/pow(10,3);
                    t_1 = t_2;

                    vector<float> dist_ball_from_cam = dist_3d(depth,p1);
                    ball_trajectory_data_cam.push_back({dist_ball_from_cam[0],
                                                        dist_ball_from_cam[1],
                                                        dist_ball_from_cam[2]});
                    cout<<origin_from_cam[0]<<" "<<origin_from_cam[1]<<" "<<origin_from_cam[2]<<endl;
                    ball_diff_ref.val[0] = dist_ball_from_cam[0]-origin_from_cam[0];
                    ball_diff_ref.val[1] = dist_ball_from_cam[1]-origin_from_cam[1];
                    ball_diff_ref.val[2] = dist_ball_from_cam[2]-origin_from_cam[2];

                    dist_ball_from_ref1.val[0] = ball_diff_ref.ddot(unitVec_a);
                    dist_ball_from_ref1.val[1] = ball_diff_ref.ddot(unitVec_b);
                    dist_ball_from_ref1.val[2] = ball_diff_ref.ddot(unitVec_c);

                    if(vel_flag == 1)
                    {
                        //double fps = 1.0/delta_t;
                        //cout<<"frames per second = "<<fps<<endl;
//                        velocity_vector.val[0]=(dist_ball_from_ref1.val[0]-pos_old.val[0])/delta_t;
//                        velocity_vector.val[1]=(dist_ball_from_ref1.val[1]-pos_old.val[1])/delta_t;
//                        velocity_vector.val[2]=(dist_ball_from_ref1.val[2]-pos_old.val[2])/delta_t;

                        //cout<<"Velocity of the ball--> a="<<velocity_vector.val[0]<<" b="<<velocity_vector.val[1]<<" c="<<velocity_vector.val[2]<<endl;

//                        ball_trajectory_data.push_back({dist_ball_from_ref1.val[0],
//                                                        dist_ball_from_ref1.val[1],
//                                                        dist_ball_from_ref1.val[2],
//                                                        velocity_vector.val[0],
//                                                        velocity_vector.val[1],
//                                                        velocity_vector.val[2]});
                        time_stamp.push_back(t_1);
                        if(publish_flag == 1)
                        {
                            ball_trajectory_msg.x.push_back(dist_ball_from_ref1.val[0]);
                            ball_trajectory_msg.y.push_back(dist_ball_from_ref1.val[1]);
                            ball_trajectory_msg.z.push_back(dist_ball_from_ref1.val[2]);
                            ball_trajectory_msg.x.push_back(dist_ball_from_cam[0]);
                            ball_trajectory_msg.y.push_back(dist_ball_from_cam[1]);
                            ball_trajectory_msg.z.push_back(dist_ball_from_cam[2]);

                            ball_trajectory_msg.t.push_back(time_stamp[point_num]);

                            if(t_1-time_stamp[0] >= 200 && publish_count == 0) //||
                                //t_1-time_stamp[0] >= 400 && publish_count == 1)
                            {
                                ball_trajectory_publisher.publish(ball_trajectory_msg);
                                publish_count++;
                            }
                        }
                        point_num++;
                    }
                    pos_old.val[0]=dist_ball_from_ref1.val[0];
                    pos_old.val[1]=dist_ball_from_ref1.val[1];
                    pos_old.val[2]=dist_ball_from_ref1.val[2];
                    vel_flag=1;

                    cout<<"Distance of ball from ref1--> a="<<dist_ball_from_ref1.val[0]<<" b="<<dist_ball_from_ref1.val[1]<<" c="<<dist_ball_from_ref1.val[2]<<endl;

                }

                circles.clear();

                //high_resolution_clock::time_point t2 = high_resolution_clock::now();
                //auto duration = duration_cast<milliseconds>(t2-t1).count();
                //cout<<"Processing time="<<duration<<endl;
            }
        }

    }


    // Signal threads to finish and wait until they do
    alive = false;
    video_processing_thread.join();
    return EXIT_SUCCESS;
}
catch (const rs2::error & e)
{
    std::cerr << "RealSense error calling " << e.get_failed_function() << "(" << e.get_failed_args() << "):\n    " << e.what() << std::endl;
    return EXIT_FAILURE;
}
catch (const std::exception & e)
{
    std::cerr << e.what() << std::endl;
    return EXIT_FAILURE;
}

float get_depth_scale(rs2::device dev)
{
    // Go over the device's sensors
    for (rs2::sensor& sensor : dev.query_sensors())
    {
        // Check if the sensor if a depth sensor
        if (rs2::depth_sensor dpt = sensor.as<rs2::depth_sensor>())
        {
            return dpt.get_depth_scale();
        }
    }
    throw std::runtime_error("Device does not have a depth sensor");
}
rs2_stream find_stream_to_align(const std::vector<rs2::stream_profile>& streams)
{
    //Given a vector of streams, we try to find a depth stream and another stream to align depth with.
    //We prioritize color streams to make the view look better.
    //If color is not available, we take another stream that (other than depth)
    rs2_stream align_to = RS2_STREAM_ANY;
    bool depth_stream_found = false;
    bool color_stream_found = false;
    for (rs2::stream_profile sp : streams)
    {
        rs2_stream profile_stream = sp.stream_type();
        if (profile_stream != RS2_STREAM_DEPTH)
        {
            if (!color_stream_found)         //Prefer color
                align_to = profile_stream;

            if (profile_stream == RS2_STREAM_COLOR)
            {
                color_stream_found = true;
            }
        }
        else
        {
            depth_stream_found = true;
        }
    }

    if(!depth_stream_found)
        throw std::runtime_error("No Depth stream available");

    if (align_to == RS2_STREAM_ANY)
        throw std::runtime_error("No stream found to align with Depth");

    return align_to;
}
vector<float> dist_3d(const rs2::depth_frame& frame, pixel u)
{
    float upixel[2]; // From pixel
    float upoint[3]; // From point (in 3D)

    // Copy pixels into the arrays (to match rsutil signatures)
    upixel[0] = u.first;
    upixel[1] = u.second;

    // Query the frame for distance
    // Note: this can be optimized
    // It is not recommended to issue an API call for each pixel
    // (since the compiler can't inline these)
    // However, in this example it is not one of the bottlenecks
    auto udist = frame.get_distance(upixel[0], upixel[1]);

    // Deproject from pixel to point in 3D
    rs2_intrinsics intr = frame.get_profile().as<rs2::video_stream_profile>().get_intrinsics(); // Calibration data
    rs2_deproject_pixel_to_point(upoint, &intr, upixel, udist);

    vector<float> point;
    point.push_back(upoint[0]);
    point.push_back(upoint[1]);
    point.push_back(upoint[2]);

    return point;
}

Vec3f* ref_init(Mat src,Vec3f ref_info[3] )
{
    const auto window_name = "Display Image";
    namedWindow(window_name, WINDOW_AUTOSIZE);
    int min_rad=3.5;
    int max_rad=9;
    int biggest_index=0;
    int middle_index=0;
    int smallest_index=0;
    int counter_cam=0;
    Vec3f unfiltered_circles[50];
    Rect rec(200,75,150,60);
    Mat gray;
    int offset_x=200;
    int offset_y=75;





    while (waitKey(1) < 0 && cvGetWindowHandle(window_name))
    {
      //Mat ref_roi=src(rec);

        cvtColor(src, gray, COLOR_BGR2GRAY);

        //ref_roi=gray(rec);
        //cvtColor(ref_roi(rec), gray, );
        //cvtColor(gray(rec),ref_roi,COLOR_BGR2GRAY);


        medianBlur(gray, gray, 1);
        rectangle(gray,rec,Scalar(255),1,8,0);
        //gray(rec).copyTo(ref_roi);

//        WhereRec.x=0;
//        WhereRec.y=0;
//        WhereRec.width=ref_roi.cols;
//        WhereRec.height=ref_roi.rows;
//        ref_roi.copyTo(gray(WhereRec));



        //gray.adjustROI(0,120,0,220);
        //imshow("ROI",gray);
        vector<Vec3f> circles;

//        input image; the number of channels can be arbitrary, but the depth should be one of
//        CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
        HoughCircles(gray(rec), circles, HOUGH_GRADIENT, 1,
                     6,  // change this value to detect circles with different distances to each other
                     15,15 ,min_rad,max_rad// change the last two parameters
                     // (min_radius & max_radius) to detect larger circles
                     );
        cout<<circles.size()<<endl;
        if (!circles.empty() && circles.size()>2 && counter_cam>20)
        {
            cout<<"in if condition circles size ="<<circles.size()<<endl;
            for (int i=0;i<circles.size();i++)
            {
                unfiltered_circles[i]=circles[i];
            }
            //Filter what we got to find biggest middle and smallest
            for( int i=0; i<circles.size() ; i++ )
            {
                if (unfiltered_circles[i].val[2]>unfiltered_circles[biggest_index].val[2])
                {
                    biggest_index=i;
                }
            }
            for( int i=0; i<circles.size(); i++ )
            {
                if(unfiltered_circles[i].val[2]<unfiltered_circles[smallest_index].val[2])
                {
                    if(unfiltered_circles[i].val[2]>0)
                    {
                        smallest_index=i;
                    }
                }
            }
            for( int i=0; i<circles.size() ; i++ )
            {
                //unfiltered_circles[i].val[2]>unfiltered_circles[middle_index].val[2]
                if (unfiltered_circles[i].val[2]<unfiltered_circles[biggest_index].val[2] && unfiltered_circles[i].val[2]>unfiltered_circles[smallest_index].val[2])
                {
                    if (abs(unfiltered_circles[i].val[2]-unfiltered_circles[biggest_index].val[2])>=1)
                    {
                        middle_index=i;
                    }
                }
            }

            //Last Step is to plot what we have

            //Biggest-----------

            Point biggest_center = Point(unfiltered_circles[biggest_index].val[0]+offset_x, unfiltered_circles[biggest_index].val[1]+offset_y);
            //circle( src, biggest_center, 1, Scalar(0,220,150), 3, LINE_AA);
            // circle outline
            float biggest_radius = unfiltered_circles[biggest_index].val[2];
            circle( src, biggest_center, biggest_radius, Scalar(0,220,150), 1, LINE_AA);

            //Middle------------

            Point middle_center = Point(unfiltered_circles[middle_index].val[0]+offset_x, unfiltered_circles[middle_index].val[1]+offset_y);
            //circle( src, middle_center, 1, Scalar(0,100,100), 3, LINE_AA);
            // circle outline
            float middle_radius = unfiltered_circles[middle_index].val[2];
            circle( src, middle_center, middle_radius, Scalar(0,100,100), 1, LINE_AA);

            //Smallest-----------

            Point smallest_center = Point(unfiltered_circles[smallest_index].val[0]+offset_x, unfiltered_circles[smallest_index].val[1]+offset_y);
            //circle( src, smallest_center, 1, Scalar(0,40,60), 3, LINE_AA);
            // circle outline
            float smallest_radius = unfiltered_circles[smallest_index].val[2];
            circle( src, smallest_center, smallest_radius, Scalar(0,40,60), 1, LINE_AA);

            //COUT for each loop

            cout<<"Biggest_radius="<<biggest_radius<<endl;

            cout<<"middle_radius="<<middle_radius<<endl;
            cout<<"Smallest_radius="<<smallest_radius<<endl;
            cout<<endl;
            imshow("detected circles", src);
            //adding offsets
            unfiltered_circles[biggest_index].val[0]= unfiltered_circles[biggest_index].val[0]+offset_x;
            unfiltered_circles[biggest_index].val[1]= unfiltered_circles[biggest_index].val[1]+offset_y;

            unfiltered_circles[middle_index].val[0]= unfiltered_circles[middle_index].val[0]+offset_x;
            unfiltered_circles[middle_index].val[1]= unfiltered_circles[middle_index].val[1]+offset_y;

            unfiltered_circles[smallest_index].val[0]= unfiltered_circles[smallest_index].val[0]+offset_x;
            unfiltered_circles[smallest_index].val[1]= unfiltered_circles[smallest_index].val[1]+offset_y;




            ref_info[0]=unfiltered_circles[biggest_index];
            ref_info[1]=unfiltered_circles[middle_index];
            ref_info[2]=unfiltered_circles[smallest_index];
            while (waitKey(1) < 0 && cvGetWindowHandle(window_name))
            {}
            return ref_info;
        }

        counter_cam++;
    }
}

void write_to_file(std::string file_name , std::vector<Vec6f> data, std::vector<double> time)
{
    std::ofstream myfile;
    int status;
    if(global_write_flag == 0)
    {
        status = std::remove("/home/abdelrhman/loggings/ball_trajectory_x.txt");
        status = std::remove("/home/abdelrhman/loggings/ball_trajectory_y.txt");
        status = std::remove("/home/abdelrhman/loggings/ball_trajectory_z.txt");
        status = std::remove("/home/abdelrhman/loggings/ball_trajectory_t.txt");
        global_write_flag = 1;
    }

    myfile.open(file_name+"_x.txt",std::ios::binary|std::ios::out|std::ios::app);
    if(myfile.is_open())
    {
        for(int i = 0;i<data.size() ;i++)
        {
            myfile<<std::to_string(data[i].val[0])<<std::endl;
        }
        myfile.close();
    }
    myfile.open(file_name+"_y.txt",std::ios::binary|std::ios::out|std::ios::app);
    if(myfile.is_open())
    {
        for(int i = 0;i<data.size();i++)
        {
            myfile<<std::to_string(data[i].val[1])<<std::endl;
        }
        myfile.close();
    }
    myfile.open(file_name+"_z.txt",std::ios::binary|std::ios::out|std::ios::app);
    if(myfile.is_open())
    {
        for(int i = 0;i<data.size() ;i++)
        {
            myfile<<std::to_string(data[i].val[2])<<std::endl;
        }
        myfile.close();
    }

    myfile.open(file_name+"_t.txt",std::ios::binary|std::ios::out|std::ios::app);
    if(myfile.is_open())
    {
        for(int i = 0;i<time.size() ;i++)
        {
            myfile<<std::to_string(time[i])<<std::endl;
        }
        myfile.close();
    }
}

Point circle_detect(Mat source_img)
{
    Mat out;
    medianBlur(source_img, source_img, 3);
    inRange(source_img, cv::Scalar(0, 30, 130), cv::Scalar(70, 255, 255), out);
    boxFilter(out, out,-1,Size(7,7));
    //adaptiveThreshold(img,img,255,ADAPTIVE_THRESH_GAUSSIAN_C,THRESH_BINARY,11,2);
    threshold(out,out,1,255,CV_THRESH_BINARY);

    //rectangle(img,trackWindow,(255,0,0),2);

    //------------------------------
    HoughCircles(out, circles, HOUGH_GRADIENT, 1,
                 100,  // change this value to detect circles with different distances to each other
                 5,5, 1, 20 // change the last two parameters
                 // (min_radius & max_radius) to detect larger circles
                 );
    if(!circles.empty())
    {
        cout<<"No. of circles= "<<circles.size()<<endl;

        Vec3i c = circles[0];
        Point center = Point(c[0], c[1]);
        // circle center
        circle( out, center, 1, Scalar(0,100,100), 2, LINE_AA);
        imshow(thresholded_image,out);
        return center;
    }
    else
    {
        Point center = Point(-1, -1);
        return center;
    }

}
Point MatchingMethod( Mat source,Mat templ)
{
    Mat img_display;
    Mat result, mask;
    bool use_mask = false;
    int match_method=1;

    /*medianBlur(source, source, 3);
    inRange(source, cv::Scalar(0, 20, 100), cv::Scalar(70, 255, 255), source);
    //boxFilter(source, source,-1,Size(7,7));
    //adaptiveThreshold(img,img,255,ADAPTIVE_THRESH_GAUSSIAN_C,THRESH_BINARY,11,2);
    threshold(source,source,1,255,CV_THRESH_BINARY_INV);*/

    source.copyTo( img_display );
    int result_cols =  source.cols - templ.cols + 1;
    int result_rows = source.rows - templ.rows + 1;
    result.create( result_rows, result_cols, CV_32FC1 );
    bool method_accepts_mask = (CV_TM_SQDIFF == match_method || match_method == CV_TM_CCORR_NORMED);
    if (use_mask && method_accepts_mask)
    { matchTemplate( source, templ, result, match_method, mask); }
    else
    { matchTemplate( source, templ, result, match_method); }
    normalize( result, result, 0, 1, NORM_MINMAX, -1, Mat() );
    double minVal; double maxVal; Point minLoc; Point maxLoc;
    Point matchLoc;
    minMaxLoc( result, &minVal, &maxVal, &minLoc, &maxLoc, Mat() );
    if( match_method  == TM_SQDIFF || match_method == TM_SQDIFF_NORMED )
    { matchLoc = minLoc; }
    else
    { matchLoc = maxLoc; }
    //rectangle( img_display, matchLoc, Point( matchLoc.x + templ.cols , matchLoc.y + templ.rows ), Scalar::all(0), 2, 8, 0 );
    rectangle( result, matchLoc, Point( matchLoc.x + templ.cols , matchLoc.y + templ.rows ), Scalar::all(0), 2, 8, 0 );
    //imshow( image_window, img_display );
    imshow( "result_window", result );
    /*double  num=0,den=0,res[3];
    double num_1 = 0, num_2 = 0, den_1 = 0, den_2= 0;
    for(int c =0; c<3; c++)
    {
        for(int i =1; i<=5; i++)
        {
            for(int j =1; j<=5; j++)
            {
                Vec3b intensity = templ.at<Vec3b>(i, j);
                Vec3b img_intensity = source.at<Vec3b>(matchLoc.y+i, matchLoc.x+j);
                num_1 = double(intensity.val[c]);
                num_2 = double(img_intensity.val[c]);
                num += pow(num_1-num_2,2);

                den_1 += pow(num_1,2);
                den_2 += pow(num_2,2);
            }
        }
        den = sqrt(den_1*den_2);
        res[c] = num/den;
    }
    double average_colors = (res[0]+res[1]+res[2])/3.0;
    cout<< "blue = "<<res[0]<< ", green = "<<res[1]<< ", red = "<<res[2]<<endl;
    cout<<"there average = "<<average_colors<<endl;
    if(average_colors<=1.2)
    {
        return matchLoc;
    }
    else {
        matchLoc=Point(-1,-1);
        return matchLoc;
    }*/

//    double filter_w = 41,filter_h = 41;
//    Mat cropped_img(int(filter_h),int(filter_w),CV_32FC1);
//    int corner_x = int(matchLoc.x-(filter_w/2 - templ.cols/2));
//    int corner_y = int(matchLoc.y-(filter_h/2 - templ.rows/2));
//    if(corner_x < 1)
//    {
//        corner_x = 1;
//    }
//    else if((corner_x+filter_w) > result.cols) // filter width exceeded image boundary from the right
//    {
//        corner_x -= (corner_x+filter_w) - result.cols;
//    }
//    if(corner_y < 1)
//    {
//        corner_y = 1;
//    }
//    else if((corner_y+filter_h) > result.rows) // filter height exceeded image boundary from the below
//    {
//        corner_y -= (corner_y+filter_h) - result.rows;
//    }
//    result(Rect(corner_x,corner_y,int(filter_w),int(filter_h))).copyTo(cropped_img);
//    subtract(cropped_img,result.at<double>(matchLoc.y+templ.rows/2,matchLoc.x+templ.cols/2),cropped_img);
//    auto average = mean(cropped_img);
//    if(average[0] > max_average)max_average = average[0];
//    if(average[0] < min_average)min_average = average[0];
//    //cout<<"max_average = "<<max_average<<endl;
//    //cout<<"min_average = "<<min_average<<endl;
//    //cout<<"average = "<<average<<endl;
//    if(average[0]>=0.2)
//    {
//        return matchLoc;
//    }
//    else {
//        matchLoc = Point(-1,-1);
//        return matchLoc;
//    }
    return matchLoc;

}
void blob_detection(Mat image)
{
    //convert to grascale
    Mat im;
    image.copyTo(im);
    cvtColor(im,im,CV_BGR2GRAY);

    // Setup SimpleBlobDetector parameters.
    SimpleBlobDetector::Params params;

    // Change thresholds
    params.minThreshold = 10;
    params.maxThreshold = 200;

    // Filter by Area.
    params.filterByArea = true;
    params.minArea = 1500;

    // Filter by Circularity
    params.filterByCircularity = true;
    params.minCircularity = 0.9;

    // Filter by Convexity
    params.filterByConvexity = true;
    params.minConvexity = 0.9;

    // Filter by Inertia
    params.filterByInertia = true;
    params.minInertiaRatio = 0.01;

    // Storage for blobs
    vector<KeyPoint> keypoints;

    // Set up detector with params
    Ptr<SimpleBlobDetector> detector = SimpleBlobDetector::create(params);

    // Detect blobs
    detector->detect( im, keypoints);

    // Draw detected blobs as red circles.
    // DrawMatchesFlags::DRAW_RICH_KEYPOINTS flag ensures
    // the size of the circle corresponds to the size of blob

    Mat im_with_keypoints;
    drawKeypoints( im, keypoints, im_with_keypoints, Scalar(0,0,255), DrawMatchesFlags::DRAW_RICH_KEYPOINTS );

    // Show blobs
    imshow("keypoints", im_with_keypoints );
    waitKey(0);

}
void CallBackFunc(int event, int x, int y, int flags, void* userdata)
{
    if  ( event == EVENT_LBUTTONDOWN )
    {
        cout << "Left button of the mouse is clicked - position (" << x << ", " << y << ")" << endl;
        pixel_pos_1.val[0] = x;
        pixel_pos_1.val[1] = y;
    }
    if  ( event == EVENT_LBUTTONUP )
    {
        cout << "Left button of the mouse is released - position (" << x << ", " << y << ")" << endl;
        pixel_pos_2.val[0] = x;
        pixel_pos_2.val[1] = y;
        found = true;
    }
//    else if ( event == EVENT_MOUSEMOVE )
//    {
//        cout << "Mouse move over the window - position (" << x << ", " << y << ")" << endl;
//    }
}
